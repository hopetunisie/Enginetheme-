<?php
#default settings
$count = 0;
$loops = array();
$args = array();
$args_common = array();
$loop = 'main';
if(empty($title)) $title = __('Latest',IT_TEXTDOMAIN);
$size = '';
$csswhite = '';
$csscol = 'col-sm-3';
$cols = 4;

#directory layout options
$categories = get_post_meta($post->ID, "_directory_categories", $single = true);
$layout = get_post_meta($post->ID, "_directory_layout", $single = true);
if(empty($layout)) $layout = 'widget_a';
$rating = get_post_meta($post->ID, "_directory_ratings_disable", $single = true);
$disable_reviewlabel = get_post_meta($post->ID, "_directory_reviewlabel_disable", $single = true);
$disabled_filters = get_post_meta($post->ID, "_directory_filters_disable", $single = true);
$sort = get_post_meta($post->ID, "_directory_sort", $single = true);
$reviews = get_post_meta($post->ID, "_directory_reviews", $single = true);
$postsperpage = get_post_meta($post->ID, "_directory_number", $single = true);
	
#page layout options
$title_meta = get_post_meta($post->ID, "_subtitle", $single = true);
if(!empty($title_meta) && $title_meta!='') $title = $title_meta;
$disable_title = get_post_meta($post->ID, IT_META_DISABLE_TITLE, $single = true);

#limit to reviews only
if($reviews) $args['meta_query'] = array(array( 'key' => IT_META_DISABLE_REVIEW, 'value' => 'true', 'compare' => '!=' ));

#override postsperpage
if(!empty($postsperpage)) $args['posts_per_page'] = $postsperpage;

#determine layout/css classes
$location = $layout;
$style = $location;
switch($location) {
	case 'widget_a':
		#defaults
	break;
	case 'widget_b':
		$size = 'square-large';		
	break;
	case 'widget_c':
		#no image
	break;
	case 'widget_d':
		$size = 'rectangle';
		$style = 'widget_c';
	break;
	case 'widget_e':
		$size = 'rectangle';
		$style = 'widget_c';
	break;
}		
		
#turn options into arrays
$categories = unserialize($categories) ? unserialize($categories) : array();
$disabled_filters = unserialize($disabled_filters) ? unserialize($disabled_filters) : array();
$disabled_count = !empty($disabled_filters) ? count($disabled_filters) : 0;
$disable_filters = $disabled_count > 6 ? true : false;

#setup loop format
$format = array('loop' => $loop, 'location' => $location, 'layout' => $layout, 'sort' => $sort, 'rating' => !$rating, 'thumbnail' => true, 'meta' => true, 'award' => true, 'icon' => true, 'badge' => true, 'excerpt' => false, 'authorship' => false, 'nonajax' => true, 'numarticles' => $postsperpage, 'disable_ads' => true, 'size' => $size, 'disable_category' => true, 'disable_reviewlabel' => $disable_reviewlabel);

#setup sortbar
$sortbarargs = array('loop' => $loop, 'location' => $location, 'layout' => $layout, 'title' => $title, 'theme_icon' => '', 'disabled_filters' => $disabled_filters, 'numarticles' => $postsperpage, 'disable_filters' => $disable_filters, 'disable_title' => false, 'thumbnail' => true, 'rating' => !$rating, 'meta' => true, 'award' => true, 'badge' => true, 'excerpt' => false, 'authorship' => false, 'icon' => true, 'size' => $size, 'default' => $sort, 'disable_category' => true, 'disable_reviewlabel' => $disable_reviewlabel);

#don't want any specific sorting added to common args
$args_common = $args;

#setup default sorting (same for all loops on the page)
switch($sort) {
	case 'recent':	
		break;
	case 'title':
		$args['orderby'] = 'title';
		$args['order'] = 'ASC';
		break;
	case 'heat':
		$args['orderby'] = 'meta_value_num';
		$args['meta_key'] = IT_HEAT_INDEX;
		break;
	case 'liked':
		$args['orderby'] = 'meta_value_num';
		$args['meta_key'] = IT_META_TOTAL_LIKES;
		break;
	case 'viewed':
		$args['orderby'] = 'meta_value_num';
		$args['meta_key'] = IT_META_TOTAL_VIEWS;	
		break;
	case 'users':
		$args['orderby'] = 'meta_value_num';
		$args['meta_key'] = IT_META_TOTAL_USER_SCORE_NORMALIZED;
		$meta_query = $args['meta_query'];
		$new_meta_query = array( array( 'key' => IT_META_TOTAL_USER_SCORE_NORMALIZED, 'value' => '0', 'compare' => 'NOT IN') );
		if(!empty($meta_query)) {
			$meta_query = array_merge($meta_query, $new_meta_query);
		} else {
			$meta_query = $new_meta_query;
		}
		$args['meta_query'] = $meta_query;	
		break;
	case 'reviewed':
		$args['orderby'] = 'meta_value_num';
		$args['meta_key'] = IT_META_TOTAL_SCORE_NORMALIZED;
		break;
	case 'commented':
		$args['orderby'] = 'comment_count';	
		break;
	case 'awarded':
		$args['orderby'] = 'date';
		$args['order'] = 'DESC';
		$meta_query = $args['meta_query'];
		$new_meta_query = array( array( 'key' => IT_META_AWARDS, 'value' => array(''), 'compare' => 'NOT IN') );
		if(!empty($meta_query)) {
			$meta_query = array_merge($meta_query, $new_meta_query);
		} else {
			$meta_query = $new_meta_query;
		}
		$args['meta_query'] = $meta_query;	
		break;
}
			
#setup loop(s)
foreach($categories as $catid) {
	$category_icon = it_get_category_icon($catid,$csswhite,16);
	$name = get_cat_name($catid);
	$args['cat'] = $catid;
	$args_common['cat'] = $catid;
	$format['container'] = 'directory-' . $catid;
	$sortbarargs['container'] = 'directory-' . $catid;	
	$sortbarargs['title'] = $name;
	$sortbarargs['category_icon'] = $category_icon;
	$sortbarargs['static_label'] = true;		
	$itposts = new WP_Query( $args );
	$numpages = $itposts->max_num_pages;		
	$loops[$catid] = array('args' => $args, 'args_common' => $args_common, 'catid' => $catid, 'sortbarargs' => $sortbarargs, 'format' => $format, 'numpages' => $numpages);
}	

$the_content = it_get_content('');

?>
    
<div class="container-fluid no-padding single-wrapper directory <?php echo $style; ?>">

	<div class="row">
    
        <div class="col-md-12">
        
        	<?php echo it_background_ad(); #full screen background ad ?>
        
        	<div class="container-inner">
            
            	<?php echo it_ad_action('directory_before'); ?>
            
            	<div class="row">
                
                	<div class="col-md-12">
                    
                    	<?php if(!$disable_title || !empty($the_content)) { ?>
                    
                            <div class="content-panel shadowed page-content">
        
                                <?php if(!$disable_title) { ?><h1 class="main-title single-title"><?php echo get_the_title(); ?></h1><?php } ?>
                                        
                                <?php echo $the_content; ?>
                                
                            </div>            
           	
            			<?php } ?>
    
                        <div class="row directory-row">
                    
                            <?php foreach($loops as $this_loop) { $count++; ?> 
                            
                                <?php $cssright = $count % $cols == 0 ? ' right' : ''; ?>
                            
                                <?php $args_encoded = json_encode($this_loop['args_common']); ?>
                            
                                <div id="directory-<?php echo $this_loop['catid']; ?>" class="post-container <?php echo $csscol; ?>" data-currentquery='<?php echo $args_encoded; ?>'>
                                
                                	<div class="shadowed content-panel">
                            
										<?php echo it_get_sortbar($this_loop['sortbarargs']); ?> 
                                    
                                        <div class="content-inner clearfix">
                                        
                                            <div class="loading load-sort"><span class="theme-icon-spin2"></span></div>
                                            
                                            <div class="loop">                            
                                                
                                                <?php $loop = it_loop($this_loop['args'], $this_loop['format']); echo $loop['content']; ?>
                                                
                                            </div>  
                                                                 
                                        </div>
                                            
                                        <?php echo it_pagination($this_loop['numpages'], $this_loop['format'], it_get_setting('page_range')); ?>                                            
                                        
                                    </div> 
                                    
                                </div>
                                
                                <?php if($count % $cols == 0) echo '</div><div class="row directory-row">'; # start a new row ?>
                                
                                <?php if($count % 2 == 0) echo '<br class="clearer hidden-lg hidden-md" />'; ?>
                            
                            <?php } ?>
                            
                        </div> 
                            
                	</div>
            
            	</div>
                
                <?php echo it_ad_action('directory_after'); ?>
                
            </div>    
    
    	</div>
        
    </div>
	
</div>  

<?php wp_reset_query(); ?>